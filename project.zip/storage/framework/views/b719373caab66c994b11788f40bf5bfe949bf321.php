<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">
            <div class="card mt-5">
                <div class="card-block">
                  <div class="form-header bg-primary">Register</div>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="md-form<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                          <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                          <label for="name" class="form-label">Name</label>
                          <?php if($errors->has('name')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('name')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                          <label for="email" class="form-label">E-Mail Address</label>
                          <?php if($errors->has('email')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                          <input id="password" type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required autofocus>
                          <label for="password" class="form-label">Password</label>
                          <?php if($errors->has('password')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('password')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form">
                          <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                          <label for="password-confirm" class="form-label">Confirm Password</label>
                        </div>

                        <div class="md-form text-sm-center">
                          <button type="submit" class="btn btn-primary btn-block">
                              Register
                          </button>
                          <a href="<?php echo e(route('login')); ?>" class="btn btn-link">Already have an Account?</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>