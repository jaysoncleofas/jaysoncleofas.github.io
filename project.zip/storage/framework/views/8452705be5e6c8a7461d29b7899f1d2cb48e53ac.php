<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php if($flash = session('message')): ?>
    <div id="flash-message" class="alert alert-success">
      <?php echo e($flash); ?>

    </div>
  <?php endif; ?>

<div class="container mt-5">
  <div class="card mb-2">
    <div class="row">
      <div class="col-sm-6">
        <h4 class="h4-responsive mt-1 ml-4">List of projects
          <a href="<?php echo e(route('projects.index')); ?>" data-toggle="tooltip" data-placement="top" title="List view">
            <i class="fa fa-list-alt"></i>
          </a>
          <a href="">
            <i class="fa fa-table" data-toggle="tooltip" data-placement="top" title="Table view"></i>
          </a>
        </h4>
      </div>
      <div class="col-md-6 text-sm-right">
        <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary">
          <i class="fa fa-plus"></i> New Project
        </a>
      </div>
    </div>
  </div>

    <div class="row">

      <div class="col-lg-12 mx-auto">
        <div class="card">
          <div class="card-block">



            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr class="primary-color white-text">
                    <th>#</th>
                    <th>Title</th>
                    <th>Body</th>
                    <th>By</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($project->id); ?></td>
                      <td><?php echo e($project->title); ?></td>
                      <td><?php echo e(substr($project->body, 0, 50)); ?><?php echo e(strlen($project->body) > 50 ? "..." : ""); ?></td>
                      <td><?php echo e($project->user->name); ?></td>
                      <td><?php echo e($project->created_at->toFormattedDateString()); ?></td>
                      <td>
                        <a href="#" class="teal-text mr-2"><i class="fa fa-pencil"></i></a>
                        <a href="#" class="red-text"><i class="fa fa-times"></i></a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/parsley.min.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $('form').parsley();

    // Tooltips Initialization
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>