<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="container mt-5">

    <div class="row">

      <div class="col-sm-6">
        <h1><?php echo e(Auth::user()->name); ?></h1>
        <p>Your Email Address is <strong><?php echo e(Auth::user()->email); ?></strong> </p>
      </div>

    </div>
    <hr>
    <form class="" action="<?php echo e(route('settings.update', 'Auth::user()->id')); ?>" method="post">
      <?php echo e(csrf_field()); ?> <?php echo e(method_field('PATCH')); ?>

       <div class="row">
         <div class="col-sm-3">
           <h3>Account</h3>
         </div>

         <div class="col-sm-4">
            <div class="md-form mt-1">
               <input type="text" name="email" value="<?php echo e(Auth::user()->email); ?>">
               <label for="">Email Address</label>
            </div>
         </div>

         <div class="col-sm-4 text-right">
           <button type="submit">Save</button>
         </div>
       </div>
       <hr>

       <div class="row">
          <div class="col-sm-4 offset-md-3">
             <div class="md-form mt-1">
                <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                <label for="">Name</label>
             </div>
             <div class="md-form">
                <input type="text" name="profession" value="<?php echo e(Auth::user()->profession); ?>">
                <label for="">Title</label>
             </div>
             <div class="md-form">
                <input type="text" name="address" value="<?php echo e(Auth::user()->address); ?>">
                <label for="">Address</label>
             </div>
             <div class="md-form">
                <input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
                <label for="">Phone number</label>
             </div>
          </div>
       </div>
    </form>
    <hr>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>