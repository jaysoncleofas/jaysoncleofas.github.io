<script src="<?php echo e(asset('MDB/js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('MDB/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('MDB/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('MDB/js/mdb.min.js')); ?>"></script>
