<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container mt-5">

   <?php if($flash = session('message')): ?>
      <div id="flash-messages" class="alert alert-success">
        <?php echo e($flash); ?>

      </div>
   <?php endif; ?>
    <div class="row">
      <div class="col-lg-12 mx-auto">
        <div class="card">
          <div class="card-block">

            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr class="primary-color white-text">
                    <th>#</th>
                    <th>Name</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($message->id); ?></td>
                      <td><?php echo e($message->firstname); ?> <?php echo e($message->lastname); ?></td>
                      <td><?php echo e(substr($message->message, 0, 50)); ?><?php echo e(strlen($message->message) > 50 ? "..." : ""); ?></td>
                      <td><?php echo e(date('M j, Y', strtotime($message->created_at))); ?></td>
                      <td>
                        <a href="<?php echo e(route('messages.show', $message->id)); ?>" class="blue-text mr-2">
                            <i class="fa fa-eye" data-toggle="tooltip" data-placement="top" title="View"></i>
                        </a>
                        <form class="" action="<?php echo e(route('messages.destroy' , $message->id)); ?>" method="post">
                           <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

                           <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete?')" data-toggle="tooltip" data-placement="top" title="Delete">
                               <i class="fa fa-times"></i>
                           </button>
                        </form>
                        <a href="<?php echo e(route('messages.destroy', $message->id)); ?>" class="red-text">

                        </a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/parsley.min.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $('form').parsley();

    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>