<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container mt-5">

    <div class="row">
      <div class="col-lg-8 mx-auto">
        <h3><i class="fa fa-user btn btn-primary"></i> <strong><?php echo e($message->firstname); ?> <?php echo e($message->lastname); ?></strong></h3>
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-2">
        <p class="float-right"></p>
      </div>
      <div class="col-lg-8">
        <div class="row">
          <div class="col-sm-6">
            <p>Email Address: <strong><?php echo e($message->email); ?></strong></p>
            <p>Phone: <strong><?php echo e($message->phone_number); ?></strong></p>
          </div>
          <div class="col-sm-6">
            <p class="float-md-right"><?php echo e($message->created_at->toDayDateTimeString()); ?> <?php echo e($message->created_at->diffforHumans()); ?></p>
            <p class="float-md-right"></p>
          </div>
        </div>
        <div class="card mb-2">
          <div class="card-block">
            <strong>Message:</strong>
            <p class="mt-1">"<?php echo e($message->message); ?>"</p>
          </div>
        </div>
        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-unique">Back</a>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/parsley.min.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $('form').parsley();
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>