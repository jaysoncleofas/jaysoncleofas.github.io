<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">
            <div class="card mt-5">
                <div class="card-block">
                  <div class="form-header bg-primary">Reset Password</div>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('password.request')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="md-form<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input id="email" type="email" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autofocus>
                          <label for="email" class=" form-label">E-Mail Address</label>
                          <?php if($errors->has('email')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                          <input id="password" type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required autofocus>
                          <label for="password" class=" form-label">Password</label>
                          <?php if($errors->has('password')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('password')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form<?php echo e($errors->has('password_confirmation') ? ' has-danger' : ''); ?>">
                          <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                          <label for="password-confirm" class="form-label">Confirm Password</label>
                          <?php if($errors->has('password_confirmation')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form">
                          <button type="submit" class="btn btn-primary btn-block">
                              Reset Password
                          </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>