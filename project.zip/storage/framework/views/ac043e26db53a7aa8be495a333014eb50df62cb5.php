<?php $__env->startSection('title', 'Request Password link'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">
            <div class="card mt-5">

                <div class="card-block">
                  <div class="form-header bg-primary">Reset Password</div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="md-form<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                          <label for="email" class="form-label">E-Mail Address</label>
                          <?php if($errors->has('email')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form">
                          <button type="submit" class="btn btn-primary btn-block">
                              Send Password Reset Link
                          </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>