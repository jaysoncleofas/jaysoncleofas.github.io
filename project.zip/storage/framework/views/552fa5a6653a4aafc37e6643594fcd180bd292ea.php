<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-projects', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="container">
    <section id="projects" class="pt-5 pb-3">
      <h2 class="h2-responsive section-heading text-center mb-2 wow bounceInDown"><?php echo e($project->title); ?></h2>

      <!-- First row -->
        <div class="row wow fadeIn" data-wow-delay="1s">

					<div class="col-lg-6 mb-2 mx-auto">
            <img src="../img/dashboard.png" class="img-fluid z-depth-2" style="height:300px;">
            <p class="mt-2"><?php echo e($project->created_at->toDayDateTimeString()); ?></p>
            <p><?php echo e($project->body); ?></p>
            <a href="/#projects" class="btn btn-success">Return</a>
					</div>

				</div>
  				<!-- /.First row -->

    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/parsley.min.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $('form').parsley();
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>