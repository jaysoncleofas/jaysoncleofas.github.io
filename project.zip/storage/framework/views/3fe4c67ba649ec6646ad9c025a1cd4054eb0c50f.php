<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="container mt-5">

    <div class="row">

      <div class="col-sm-6">
        <h1><?php echo e(Auth::user()->name); ?></h1>
        <p>Your Email Address is <strong><?php echo e(Auth::user()->email); ?></strong> </p>
      </div>

    </div>
    <hr>
    <div class="row">

      <div class="col-sm-3">
        <h3>Account</h3>
      </div>
      <div class="col-sm-4">
        <p>Email Addess</p>
        <p><?php echo e(Auth::user()->email); ?></p>
        <p>Profession</p>
        <p><?php echo e(Auth::user()->profession); ?></p>
      </div>
      <div class="col-sm-4">
        <p>Address</p>
        <p><?php echo e(Auth::user()->address); ?></p>
        <p>Phone number</p>
        <p><?php echo e(Auth::user()->phone); ?></p>
      </div>
      <div class="col-sm-1">
        <a href="<?php echo e(route('settings.edit', Auth::user()->id)); ?>">Edit</a>
      </div>

    </div>
    <hr>
    <div class="row">

      <div class="col-sm-3">
        <h3>Security</h3>
      </div>
      <div class="col-sm-4">
        <p>Password</p>
        <a href="#">Change Password...</a>
      </div>

    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>