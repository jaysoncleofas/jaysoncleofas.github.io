<div class="container">
  <section id="skills" class="pt-5 pb-3">
    <h2 class="h2-responsive section-heading text-center pb-2 wow bounceInDown">What i do?</h2>
    <p class="text-center pb-2 wow bounceInDown">Technologies I am using in Web development.</p>

    <!-- First row -->
				<div class="row text-center wow fadeIn" data-wow-delay="1s">

					<div class="col-md-12 col-lg-4 mb-2">

						<i class="fa fa-code deep-orange-text fa-4x" aria-hidden="true"></i>
						<h4 class="lead mt-2 mb-2 text-uppercase"><?php echo e($tags[1]->name); ?></h4>
						<ul class="list-group z-depth-0 pb-3">
							<?php $__currentLoopData = $dev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li class="list-group-item flex-column"><?php echo e($devs->skill); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

					</div>
					<div class="col-md-12 col-lg-4 mb-2">

						<i class="fa fa-paint-brush green-text fa-4x" aria-hidden="true"></i>
						<h4 class="lead mt-2 mb-2 text-uppercase"><?php echo e($tags[0]->name); ?></h4>
						<ul class="list-group z-depth-0 pb-3">
							<?php $__currentLoopData = $des; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li class="list-group-item flex-column"><?php echo e($desi->skill); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

					</div>
					<div class="col-md-12 col-lg-4 mb-2">

						<i class="fa fa-wrench blue-text fa-4x" aria-hidden="true"></i>
						<h4 class="lead mt-2 mb-2 text-uppercase"><?php echo e($tags[2]->name); ?></h4>
						<ul class="list-group z-depth-0 pb-3">
							<?php $__currentLoopData = $tool; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tools): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li class="list-group-item flex-column"><?php echo e($tools->skill); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

					</div>

				</div>
				<!-- /.First row -->
  </section>
</div>

<!--Mask-->

<!--/.Mask-->
