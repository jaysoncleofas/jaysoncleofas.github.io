<div class="container">
  <section id="about" class="pt-5 pb-5">
    <h2 class="h2-responsive section-heading text-center mb-4 wow bounceInDown">Who am i?</h2>

    <div class="row">

      <div class="col-lg-4 pb-2">
        <img src="../img/ok.jpg" alt="My photo" class="img-fluid z-depth-2 wow slideInLeft">
      </div>

      <div class="col-lg-8 wow slideInRight">
        <p class="lead">I'm a freelance web developer with 2+ years in web development, from Paniqui Tarlac</p>
          <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo animi soluta ratione quisquam, dicta ab cupiditate iure eaque? Repellendus voluptatum, magni impedit eaque delectus, beatae maxime temporibus maiores quibusdam quasi.</span><span>Rem magnam ad perferendis iusto sint tempora ea voluptatibus iure, animi excepturi modi aut possimus in hic molestias repellendus illo ullam odit quia velit. Qui expedita sit quo, maxime molestiae.</span></p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi sapiente, consequuntur dolore praesentium non suscipit minus repudiandae, nesciunt placeat, vel nostrum magni pariatur accusantium laudantium.</p>
      </div>

    </div>

  </section>
</div>

<!--Mask-->

<!--/.Mask-->
