<?php $__env->startSection('stylesheets'); ?>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <main>
    <?php echo $__env->make('index.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('index.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('index.skills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('index.projects', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('index.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Scrollspy -->
    <div class="dotted-scrollspy hidden-sm-down">
        <ul class="nav smooth-scroll d-flex flex-column">
            <li class="nav-item"><a class="nav-link" href="#home"><span></span></a></li>
            <li class="nav-item"><a class="nav-link" href="#about"><span></span></a></li>
            <li class="nav-item"><a class="nav-link" href="#skills"><span></span></a></li>
            <li class="nav-item"><a class="nav-link" href="#projects"><span></span></a></li>
            <li class="nav-item"><a class="nav-link" href="#contact"><span></span></a></li>
            <li class="nav-item"><a class="nav-link" href="#footer"><span></span></a></li>
        </ul>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script type="text/javascript" src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>

  <script type="text/javascript">

    new WOW().init();

    $('body').scrollspy({
        target: '.dotted-scrollspy'
    });

    $(".smooth-scroll").on("click","a",function(e){
      e.preventDefault();
      var t=$(this).attr("href"),
      n=$(this).attr("data-offset")?$(this).attr("data-offset"):0;
      $("body,html").animate({scrollTop:$(t).offset().top-n},700)
    });

    $('form').parsley();

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>