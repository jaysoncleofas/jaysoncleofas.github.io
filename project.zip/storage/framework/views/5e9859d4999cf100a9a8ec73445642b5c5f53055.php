<?php $__env->startSection('title', '| Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">
            <div class="card mt-5">
                <div class="card-block">
                  <div class="form-header bg-primary">Login</div>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('login')); ?>" data-parsley-validate>
                        <?php echo e(csrf_field()); ?>


                        <div class="md-form<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                          <label for="email" class="form-label">E-Mail Address</label>
                          <?php if($errors->has('email')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                          <input id="password" type="password" class="form-control" name="password" required>
                          <label for="password" class="form-label">Password</label>
                          <?php if($errors->has('password')): ?>
                              <span class="text-danger">
                                  <strong><?php echo e($errors->first('password')); ?></strong>
                              </span>
                          <?php endif; ?>
                        </div>

                        <div class="md-form mb-5">
                          <div class="checkbox">
                              <label>
                                  <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                              </label>
                          </div>
                        </div>

                        <div class="md-form text-center">
                          <button type="submit" class="btn btn-primary btn-block">
                              Signin
                          </button>
                          <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                              Forgot Your Password?
                          </a>
                          <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                              Register
                          </a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script type="text/javascript" src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>

  <script type="text/javascript">

    $('form').parsley();

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>