<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials._nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<div class="container mt-3">

    <div class="row">
      <div class="col-lg-8 mx-auto">
        <div class="row">
          <div class="col-md-6">
            <h4 class="h4-responsive mt-1">Edit project</h4>
          </div>
        </div>

        <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="post" data-parsley-validate>
          <?php echo e(csrf_field()); ?> <?php echo e(method_field('PATCH')); ?>

          <div class="card mb-2 mt-1">
            <div class="card-block">
              <div class="md-form <?php echo e($errors->has('title') ? 'has-danger' : ''); ?>">
                <input type="text" class="form-control" name="title" value="<?php echo e($project->title); ?>"placeholder="" required="">
                <label for="">Title</label>
                <?php if($errors->has('title')): ?>
                  <span class="text-danger">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-block">
              <div class="md-form <?php echo e($errors->has('body') ? 'has-danger' : ''); ?>">
                <textarea name="body" class="md-textarea" rows="10" cols="100" value="<?php echo e($project->body); ?>" placeholder="" required=""><?php echo e($project->body); ?></textarea>
                <label for="">Body</label>
                <?php if($errors->has('body')): ?>
                  <span class="text-danger">
                    <strong><?php echo e($errors->first('body')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="card mb-2 mt-1">
            <div class="card-block">
              <div class="md-form <?php echo e($errors->has('slug') ? 'has-danger' : ''); ?>">
                <input type="text" class="form-control" name="slug" value="<?php echo e($project->slug); ?>"placeholder="" required="">
                <label for="">Slug</label>
                <?php if($errors->has('slug')): ?>
                  <span class="text-danger">
                    <strong><?php echo e($errors->first('slug')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="md-form mt-2 float-right">
            <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-primary">Cancel</a>
          </div>
          <div class="md-form mt-2 float-right">
            <button type="submit" name="button" class="btn btn-success">Save Changes</button>
          </div>
        </form>

      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/parsley.min.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $('form').parsley();
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>