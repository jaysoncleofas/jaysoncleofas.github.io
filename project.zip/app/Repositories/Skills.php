<?php

  namespace App\Repositories;
  use App\Skill;

  class Skills
  {
    // public function all()
    // {
    //   return Skill::all();
    // }
    // public function find()
    // {
    //
    // }
  }
