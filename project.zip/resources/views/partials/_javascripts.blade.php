<script src="{{ asset('MDB/js/jquery-3.1.1.min.js') }}"></script>
<script src="{{ asset('MDB/js/tether.min.js') }}"></script>
<script src="{{ asset('MDB/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('MDB/js/mdb.min.js') }}"></script>
