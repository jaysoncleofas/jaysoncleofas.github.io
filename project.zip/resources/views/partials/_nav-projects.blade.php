<!--Navbar-->
<nav class="navbar navbar-projects fixed-top navbar-dark teal accent-4">
    <div class="container">
        <a class="navbar-brand" href="#">{{ config('app.name') }}</a>
    </div>
</nav>
<!--/.Navbar-->
